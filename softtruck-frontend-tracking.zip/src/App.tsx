import MapView from "./components/MapView/MapView";

function App() {
  return (
    <>
      <MapView />
    </>
  );
}

export default App;
